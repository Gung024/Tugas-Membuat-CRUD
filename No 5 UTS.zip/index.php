<?php
require 'koneksi.php';

// Ambil data kategori
$result_kategori = $conn->query("SELECT * FROM data_kategori ORDER BY id ASC");

// Ambil data produk
$result_produk = $conn->query("SELECT * FROM data_produk ORDER BY id ASC");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>POS Mini - Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
<div class="container py-4">

    <h1 class="mb-4">Dashboard POS Mini</h1>

    <!-- Kategori -->
    <div class="mb-5">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Data Kategori</h2>
            <a href="tambah_kategori.php" class="btn btn-primary">Tambah Kategori</a>
        </div>

        <table class="table table-bordered table-striped table-hover">
            <thead class="table-primary">
                <tr>
                    <th>ID</th>
                    <th>Nama Kategori</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result_kategori->num_rows > 0): ?>
                <?php while($row = $result_kategori->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row["id"] ?></td>
                        <td><?= htmlspecialchars($row["nama_kategori"]) ?></td>
                        <td>
                            <a href="edit_kategori.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="hapus_kategori.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus kategori ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="3" class="text-center">Tidak ada data kategori</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Produk -->
    <div>
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h2>Data Produk</h2>
            <a href="tambah_produk.php" class="btn btn-success">Tambah Produk</a>
        </div>

        <table class="table table-bordered table-striped table-hover">
            <thead class="table-success">
                <tr>
                    <th>ID</th>
                    <th>Kode Produk</th>
                    <th>Kategori</th>
                    <th>Nama Produk</th>
                    <th>Stok</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if ($result_produk->num_rows > 0): ?>
                <?php while($row = $result_produk->fetch_assoc()): ?>
                    <tr>
                        <td><?= $row["id"] ?></td>
                        <td><?= htmlspecialchars($row["kode_produk"]) ?></td>
                        <td><?= htmlspecialchars($row["kategori"]) ?></td>
                        <td><?= htmlspecialchars($row["nama_produk"]) ?></td>
                        <td><?= $row["stok_produk"] ?></td>
                        <td>
                            <a href="edit_produk.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-warning">Edit</a>
                            <a href="hapus_produk.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-danger" onclick="return confirm('Yakin ingin hapus produk ini?')">Hapus</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr><td colspan="6" class="text-center">Tidak ada data produk</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
</body>
</html>
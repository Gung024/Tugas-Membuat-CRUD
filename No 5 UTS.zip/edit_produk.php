<?php
require 'koneksi.php';

if (!isset($_GET['id'])) {
    header('Location: index.php');
    exit;
}

$id = intval($_GET['id']);
$error = '';

// Ambil data produk
$stmt = $conn->prepare("SELECT kode_produk, kategori, nama_produk, stok_produk FROM data_produk WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$stmt->bind_result($kode_produk, $kategori, $nama_produk, $stok_produk);
if (!$stmt->fetch()) {
    $stmt->close();
    header('Location: index.php');
    exit;
}
$stmt->close();

// Ambil list kategori
$kategori_result = $conn->query("SELECT nama_kategori FROM data_kategori ORDER BY nama_kategori ASC");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $kode_baru = trim($_POST['kode_produk']);
    $kategori_baru = trim($_POST['kategori']);
    $nama_baru = trim($_POST['nama_produk']);
    $stok_baru = intval($_POST['stok_produk']);

    if ($kode_baru === '' || $kategori_baru === '' || $nama_baru === '' || $stok_baru < 0) {
        $error = "Semua field harus diisi dengan benar.";
    } else {
        $stmt = $conn->prepare("UPDATE data_produk SET kode_produk = ?, kategori = ?, nama_produk = ?, stok_produk = ? WHERE id = ?");
        $stmt->bind_param("sssii", $kode_baru, $kategori_baru, $nama_baru, $stok_baru, $id);
        if ($stmt->execute()) {
            header('Location: index.php');
            exit;
        } else {
            $error = "Gagal mengupdate produk.";
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Edit Produk</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body class="bg-light">
<div class="container py-4">
    <h1 class="mb-4">Edit Produk</h1>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="post" action="">
        <div class="mb-3">
            <label for="kode_produk" class="form-label">Kode Produk</label>
            <input type="text" name="kode_produk" id="kode_produk" class="form-control" required autofocus value="<?= htmlspecialchars($kode_produk) ?>" />
        </div>
        <div class="mb-3">
            <label for="kategori" class="form-label">Kategori</label>
            <select name="kategori" id="kategori" class="form-select" required>
                <option value="" disabled>-- Pilih Kategori --</option>
                <?php while ($kat = $kategori_result->fetch_assoc()): ?>
                    <option value="<?= htmlspecialchars($kat['nama_kategori']) ?>" <?= ($kat['nama_kategori'] === $kategori) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($kat['nama_kategori']) ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="nama_produk" class="form-label">Nama Produk</label>
            <input type="text" name="nama_produk" id="nama_produk" class="form-control" required value="<?= htmlspecialchars($nama_produk) ?>" />
        </div>
        <div class="mb-3">
            <label for="stok_produk" class="form-label">Stok Produk</label>
            <input type="number" name="stok_produk" id="stok_produk" class="form-control" min="0" value="<?= htmlspecialchars($stok_produk) ?>" required />
        </div>
        <button type="submit" class="btn btn-primary">Update</button>
        <a href="index.php" class="btn btn-secondary">Batal</a>
    </form>
</div>
</body>
</html>